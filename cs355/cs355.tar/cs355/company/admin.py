from company.models import Employee, Department
from django.contrib import admin


class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['fName', 'lName', 'ssn', 'bDate', 'sex' ]
    list_filter = ['sex']
    
admin.site.register( Employee, EmployeeAdmin )

    
