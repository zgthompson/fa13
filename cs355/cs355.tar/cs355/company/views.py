from django.shortcuts import render_to_response
import datetime
from company.models import Employee

def list_employees(request):
    employees = Employee.objects.all()
    num_emps = len( employees )
    context = {'num_employees': num_emps,
               'employees': employees}
    return render_to_response('employee.html', context )

    
